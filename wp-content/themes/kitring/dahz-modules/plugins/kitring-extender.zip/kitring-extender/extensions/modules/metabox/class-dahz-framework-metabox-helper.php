<?php

if( !class_exists( 'Dahz_Framework_Metabox_Helper' ) ) {

    Class Dahz_Framework_Metabox_Helper {

        public function dahz_framework_get_posts(){

        }

        public function dahz_framework_get_products(){

        }

        public function dahz_framework_get_categories(){
            
        }

    }

}