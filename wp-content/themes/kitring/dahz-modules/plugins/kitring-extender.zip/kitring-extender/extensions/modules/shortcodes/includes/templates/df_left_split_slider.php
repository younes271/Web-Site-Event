<?php

/*  */

?>
<div class="ms-left <?php echo esc_attr( $extra_class ); ?>">
	<?php echo wpb_js_remove_wpautop( $content ); ?>
</div>