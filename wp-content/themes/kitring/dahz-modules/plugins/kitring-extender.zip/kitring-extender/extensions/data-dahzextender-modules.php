<?php
return array(
	'panels'			=> array(),
	'social-account'	=> array(),
	'contact-form'		=> array(
		'class_dependencies'	=> array( 'WPCF7' )
	),
	'content-blocks'	=> array(),
	'portfolios'		=> array(),
	'metabox'			=> array(),
	'merge-scripts'		=> array(),
	'widget'			=> array(),
	'shortcodes'		=> array(
		'class_dependencies'	=> array( 'Vc_Manager' )
	),
	'booked'			=> array(
		'class_dependencies'	=> array( 'booked_plugin' )
	)
);
