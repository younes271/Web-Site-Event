<?php

    echo do_shortcode(
        sprintf(
            '[product_page id="%1$s"]',
            $product_ids

            )
    );

?>
