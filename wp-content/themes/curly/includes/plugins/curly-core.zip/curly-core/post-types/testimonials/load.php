<?php

include_once CURLY_CORE_CPT_PATH . '/testimonials/testimonials-register.php';
include_once CURLY_CORE_CPT_PATH . '/testimonials/helper-functions.php';