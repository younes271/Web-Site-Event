<?php

include_once CURLY_CORE_SHORTCODES_PATH . '/info-section/functions.php';
include_once CURLY_CORE_SHORTCODES_PATH . '/info-section/info-section.php';