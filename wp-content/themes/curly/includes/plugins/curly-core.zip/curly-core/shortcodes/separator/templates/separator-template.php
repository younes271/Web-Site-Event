<div class="mkdf-separator-holder clearfix <?php echo esc_attr($holder_classes); ?>">
    <div class="mkdf-separator" <?php echo curly_mkdf_get_inline_style($holder_styles); ?>></div>
</div>
