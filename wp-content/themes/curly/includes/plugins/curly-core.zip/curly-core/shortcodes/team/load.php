<?php

include_once CURLY_CORE_SHORTCODES_PATH . '/team/functions.php';
include_once CURLY_CORE_SHORTCODES_PATH . '/team/team.php';