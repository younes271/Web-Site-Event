<?php

include_once 'const.php';
include_once 'lib/curly-twitter-api.php';
include_once 'widgets/load.php';

//load shortcodes
require_once 'lib/shortcode-interface.php';
require_once 'shortcodes/shortcodes-functions.php';