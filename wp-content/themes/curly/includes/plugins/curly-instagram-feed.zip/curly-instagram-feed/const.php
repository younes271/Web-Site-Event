<?php

define('CURLY_INSTAGRAM_FEED_VERSION', '2.1.3');
define('CURLY_INSTAGRAM_ABS_PATH', dirname(__FILE__));
define('CURLY_INSTAGRAM_REL_PATH', dirname(plugin_basename(__FILE__)));
